# Budget Mobile (PWA)
Mobile‑first, offline‑ready expense tracker. iPhone PWA and GitHub Pages friendly.

**Deploy**: push to a repo → Settings → Pages → Branch: main → Folder: /root → Save.

**Install on iPhone**: open in Safari → Share → Add to Home Screen.
